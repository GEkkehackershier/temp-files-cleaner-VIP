﻿using System;
using System.IO;
using System.Threading;
using System.Windows.Forms;

class Program
{
    static void Main(string[] args)
    {
        try
        {
            string tempFolderPath = @"C:\Users\Jayden\AppData\Local\Temp";
            string windowsTempFolderPath = @"C:\Windows\Temp";

            // Cleanup Jayden's Temp Folder
            DirectoryInfo jaydenTempDirectory = new DirectoryInfo(tempFolderPath);
            foreach (FileInfo file in jaydenTempDirectory.GetFiles())
            {
                try
                {
                    if (!IsFileLocked(file))
                    {
                        file.Delete();
                        Console.WriteLine($"Deleted file: {file.FullName}");
                    }
                    else
                    {
                        Console.WriteLine($"Skipped locked file: {file.FullName}");
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Failed to delete file: {file.FullName} - {ex.Message}");
                }
            }

            foreach (DirectoryInfo dir in jaydenTempDirectory.GetDirectories())
            {
                try
                {
                    dir.Delete(true);
                    Console.WriteLine($"Deleted directory: {dir.FullName}");
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Failed to delete directory: {dir.FullName} - {ex.Message}");
                }
            }

            // Cleanup Windows Temp Folder
            DirectoryInfo windowsTempDirectory = new DirectoryInfo(windowsTempFolderPath);
            foreach (FileInfo file in windowsTempDirectory.GetFiles())
            {
                try
                {
                    if (!IsFileLocked(file))
                    {
                        file.Delete();
                        Console.WriteLine($"Deleted file: {file.FullName}");
                    }
                    else
                    {
                        Console.WriteLine($"Skipped locked file: {file.FullName}");
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Failed to delete file: {file.FullName} - {ex.Message}");
                }
            }

            foreach (DirectoryInfo subDir in windowsTempDirectory.GetDirectories())
            {
                try
                {
                    subDir.Delete(true);
                    Console.WriteLine($"Deleted directory: {subDir.FullName}");
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Failed to delete directory: {subDir.FullName} - {ex.Message}");
                }
            }

            MessageBox.Show("Successfully cleaned up both temp folders", "Cleanup Complete", MessageBoxButtons.OK, MessageBoxIcon.Information);
            Thread.Sleep(3000); // Wait for 3 seconds
        }
        catch (Exception ex)
        {
            Console.WriteLine($"An error occurred: {ex.Message}");
        }
    }

    static bool IsFileLocked(FileInfo file)
    {
        FileStream stream = null;

        try
        {
            stream = file.Open(FileMode.Open, FileAccess.ReadWrite, FileShare.None);
        }
        catch (IOException)
        {
            // The file is locked
            return true;
        }
        finally
        {
            stream?.Close();
        }

        // The file is not locked
        return false;
    }
}
